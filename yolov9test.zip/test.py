import yaml
import torch
import cv2
import pandas as pd
import sys
import os
import numpy as np
from pathlib import Path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

# Import necessary modules
from models.common import DetectMultiBackend
from utils.general import check_img_size, non_max_suppression, scale_boxes
from utils.plots import Annotator, colors
from utils.torch_utils import select_device
from utils.dataloaders import LoadImages

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"Using device: {device}")

# Load model
model = DetectMultiBackend('yolov9-c.pt', device=device)
model.eval()

# Get model stride and image size
stride = max(int(model.stride), 32)
imgsz = check_img_size((640, 640), s=stride)  # check image size

# COCO 클래스 이름 로드
COCO_CLASSES = [
    "person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck",
    "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench",
    # ... 생략 ...
]

person_class_id = COCO_CLASSES.index("person")

# 비디오 로드
cap = cv2.VideoCapture(r'E:\media\02_people.mp4')

while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break

    # Resize image to model input size
    frame = cv2.resize(frame, (imgsz[0], imgsz[1]))

    # BGR → RGB 변환
    rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # 텐서 변환 및 정규화
    img_tensor = torch.from_numpy(rgb).float().permute(2, 0, 1).unsqueeze(0) / 255.0
    img_tensor = img_tensor.to(device)

    # 추론
    with torch.no_grad():
        pred = model(img_tensor)[0]
        # Apply NMS
        pred = non_max_suppression(pred, 0.25, 0.45, classes=None, max_det=1000)[0]

    # 감지 결과 필터링
    if pred is not None and len(pred):
        # Convert predictions to numpy
        pred = pred.cpu().numpy()
        for *box, conf, cls in pred:
            if int(cls) == person_class_id:
                x1, y1, x2, y2 = map(int, box)
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0,255,0), 2)
                cv2.putText(frame, f'person {conf:.2f}', (x1, y1 - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0,255,0), 2)

    cv2.imshow('YOLOv9 Person Detection', frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()